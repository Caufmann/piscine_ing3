<?php
session_start();
$database = "ece_amazon";
//connectez-vous dans votre BDD
//Rappel: votre serveur = localhost et votre login = root et votre password = <rien>
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

      if($db_found)  
      {
        

         if ($_POST['reduc20'])
        {


          $sql="UPDATE article
                  SET Reduction_prix = 20
                  WHERE Id_article>0";
                  $result = mysqli_query($db_handle, $sql);
          $sql1="UPDATE Panier
                  SET Reduction_prix = 20
                  WHERE Id_article>0";
                  $result = mysqli_query($db_handle, $sql1);
    
          
             header("Location:votre_compte.php");
          }

        
      else if ($_POST['reduc30'])
        {

          $sql="UPDATE article
                  SET Reduction_prix = 30
                  WHERE Id_article>0";
                  $result = mysqli_query($db_handle, $sql);

                  $sql1="UPDATE Panier
                  SET Reduction_prix = 30
                  WHERE Id_article>0";
                  $result = mysqli_query($db_handle, $sql1);
    
             header("Location:votre_compte.php");
          }

      else if ($_POST['noreduc'])
        {

          $sql="UPDATE article
                  SET Reduction_prix = 0
                  WHERE Id_article>0";
                  $result = mysqli_query($db_handle, $sql);

                  $sql1="UPDATE Panier
                  SET Reduction_prix = 0
                  WHERE Id_article>0";
                  $result = mysqli_query($db_handle, $sql1);
    
             header("Location:votre_compte.php");
          
        }
      }
      
    

?>