<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js">
  </script>
	<link rel="stylesheet" type="text/css" href="magasin.css">
</head>
<body>
  <nav class="navbar navbar-expand-md navbar-light bg-light">
      <a class="navbar-brand" href="magasin.php">ECE Amazon</a>
      <ul class="navbar-nav">
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Categories</a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="livres.php">Livres</a>
            <a class="dropdown-item" href="musique.php">Musique</a>
            <a class="dropdown-item" href="vetements.php">Vetements</a>
            <a class="dropdown-item" href="sportsetloisirs.php">Sports et loisirs</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="categories.php">Toutes les categories</a>
          </div>
        </li>
        <li class="nav-item"><a class="nav-link" href="votre_compte.php">Votre compte</a></li>
        <li class="nav-item"><a class="nav-link" href="panier.php">Panier</a></li>
        <li class="nav-item"><a class="nav-link" href="connecter1.php">Se connecter</a></li>
        <li class="nav-item"><a class="nav-link" href="logout.php">Se deconnecter</a></li>
      </ul>
  </nav>


 <?php
  session_start();
  $database = "ece_amazon";
//connectez-vous dans votre BDD
//Rappel: votre serveur = localhost et votre login = root et votre password = <rien>
$db_handle = mysqli_connect('localhost', 'root', '');
$db_found = mysqli_select_db($db_handle, $database);

if ($db_found) 
    {


      $sql = "  SELECT * FROM administrateur WHERE Id = '".$_SESSION["Id"]."' ";
      $result = mysqli_query($db_handle, $sql);
      if (mysqli_num_rows($result) == 0) 
      {
        //l'article recherché n'existe pas
      echo "Votre profil n'a pas été trouvé";
       header("Location:votre_compte.php");

      } 
      else 
      {
        echo "Voilà votre profil :". "<br>". "<br>";
      //on trouve l'article recherché
        while ($data = mysqli_fetch_assoc($result)) 
        {         
          echo "Mail: " . $data['Mail'] . "<br>";
          echo "Pseudo: " . $data['Pseudo'] . "<br>";
          $tof=$data['Photo'];
          $tof_fond=$data['Img_fond'];

         echo"<html>
              <head>
              
              </head>
                <table>
                <tr>
                 <td><img src=\"img/$tof\" alt=\"user pic\" style=\"max-width:200px\"border=\"0\"></td>
                 <td><img src=\"img/$tof_fond\" alt=\"user pic\" style=\"max-width:200px\"border=\"0\"></td>
               </tr>
               </table>
               </html>"; 
          echo "<br>";
        }
      }
    }
    $sql5 = " SELECT Reduction_prix FROM article LIMIT 1 ";
    $result5 = mysqli_query($db_handle, $sql5);
    if (mysqli_num_rows($result5) == 0) 
  {
     
  }
  else
  {
    $data = mysqli_fetch_assoc($result5);
    $reduc_actu=$data['Reduction_prix'];
    $la_reduc=-($reduc_actu);
    }  
    

    
    
     echo"<!DOCTYPE html>
                <html>
                 <p>Si vous voulez realiser une promotion, choisissez un montant valable sur tous les articles: <br></p>
                  reduction actuelle:  $la_reduc %

                         <form  action='test_promotion.php' method='post'>
                       <table>
                        <tr>
                          <td >
                          <input type='submit' name='reduc20' value='-20%'>
                          </td>
                          <td >
                          <input type='submit' name='reduc30' value='-30%'>
                          </td>
                          <td >
                          <input type='submit' name='noreduc' value='remettre a zero'>
                          </td>
                       </tr>
                       </table>
                       </form>
                    </html>";



                    echo " Voici la liste de tous les articles : <br>";
    //on cherche l'article avec les param Categorie et Nom 
    $sql2 = " SELECT * FROM article ";
    $result2 = mysqli_query($db_handle, $sql2);
    
      while ($data = mysqli_fetch_assoc($result2)) 
      {
        $tof=$data['Photo1'];
        $name=$data['Nom'];
        $price=$data['Prix'];
        $id_article = $data['Id_article'];
        $categorie = $data['Categorie'];

         echo"<html>
         <div class='col-lg-8 col-md-4 mb-4'>
            	<div class='card h-100'>
              <table>
              <tr>
              <td>Id de l'article = $id_article</td>
               <td><img src=\"img/$tof\" style=\"max-width:100px\"border=\"0\"></td>
               <td>$name</td>
               <td>$price €</td>
             </tr>
             </table>
             </div>
             </div>
             </html>";
      }


  ?>

<form action="suppression_article.php" method="post">
  <td>Id de l article à supprimer :</td>
      <td><input type="number" name="id_value"></td>
      <button class="button" name="button2">Supprimer article</button>
      <br>
      <br>
  </form>

  <button class="button" name="button2" onclick="document.location.href='ajouter_article.php'">Ajouter des articles</button>
  <br>
  <br>
<?php
  echo " Voici la liste de tous les vendeurs :";

    //on cherche l'article avec les param Categorie et Nom 
    $sql2 = " SELECT * FROM vendeur ";
    $result2 = mysqli_query($db_handle, $sql2);
    
      while ($data = mysqli_fetch_assoc($result2)) 
      {
        $tof=$data['Photo'];
        $name=$data['Pseudo'];
        $price=$data['Mail'];
        $id_article = $data['Id'];
        

         echo"<html>
         <div class='col-lg-8 col-md-4 mb-4'>
            	<div class='card h-100'>
              <table>
              <tr>
              <td>Id du vendeur = $id_article</td>
               <td><img src=\"img/$tof\" style=\"max-width:100px\"border=\"0\"></td>
               <td>$name</td>
               <td>$price</td>
             </tr>
             </table>
             </div>
             </div>
             </html>";
      }


  ?>
    <form action="suppression_vendeur.php" method="post">
  <td>Id du vendeur à supprimer:</td>
      <td><input type="number" name="id_value"></td>
      <button class="button" name="button2">Supprimer vendeur</button>
      <br>
      <br>
  </form>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
<div id="scrollUp"><a href="#top"><img src="C:\wamp64\www\PP\to_top.png"/></a></div>
<link href='magasin.css' rel='stylesheet' type='text/css'>
<script src="magasin.js"></script>

<footer class="py-5 bg-dark">
	<div class="container">
    	<p class="m-0 text-center text-white">Copyright &copy; ECE Amazon 2019</p>
	</div>
</footer>

</body>
</html>