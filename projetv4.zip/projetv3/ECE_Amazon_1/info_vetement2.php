<?php  
session_start();

	//identifier votre BDD 
	
		$database = "ece_amazon";
		$db_handle = mysqli_connect('localhost', 'root', '');
		$db_found = mysqli_select_db($db_handle, $database);
		if($db_found){	        	

			$couleur = isset($_POST["Nom"]) ? $_POST["Nom"] : "";			
			$taille = isset($_POST["Prenom"]) ? $_POST["Prenom"] : "";		
            $quantite = isset($_POST["Adresse"]) ? $_POST["Adresse"] : "";
            $typeitem = isset($_POST["type_item"]) ? $_POST["type_item"] : "";    
            $genre = isset($_POST["Genre"]) ? $_POST["Genre"] : "";     	

        	//BLINDAGE
        	if(empty($couleur) || empty($taille) || empty($quantite) || empty($genre)) {
				header("Location: info_vetement.php?signup=empty&nom=$couleur&prenom=$taille&adresse=$quantite");    
			}else{
                
        
                $id_value = $_SESSION['var'];
                                    $sql2 = "SELECT max(Code_article) FROM vetement";
			
									$results = mysqli_query($db_handle, $sql2);
									$data = mysqli_fetch_assoc($results);
									$idmax=$data['max(Code_article)'];
		
                                    $idmaxi=$idmax+1;
                                    
                                    
									$addsql = "INSERT INTO `vetement` (`Identifiant`,`Code_article`, `Categorie`, `Type`, `Taille`, `Couleur`,`Genre`, `Quantite`) VALUES ($id_value, $idmaxi, 'Vetement', '$typeitem', '$taille', '$couleur', '$genre', $quantite)";
									//RAJOUTER LES AJOUTS DE PHOTOS
                                    $result2 = mysqli_query($db_handle, $addsql);   
                                    header("Location: info_vetement.php");                            
                                   
									
									exit();
								}
							
							
		}
		else{
		echo 'BD not found';
		}
		mysqli_close($db_handle);	 
	

	  
?>

