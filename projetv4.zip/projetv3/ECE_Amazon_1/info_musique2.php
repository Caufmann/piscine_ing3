<?php  
session_start();

	//identifier votre BDD 
	
		$database = "ece_amazon";
		$db_handle = mysqli_connect('localhost', 'root', '');
		$db_found = mysqli_select_db($db_handle, $database);
		if($db_found){	        	

			$artiste = isset($_POST["Nom"]) ? $_POST["Nom"] : "";			
			$album = isset($_POST["Prenom"]) ? $_POST["Prenom"] : "";		
            $quantite = isset($_POST["Adresse"]) ? $_POST["Adresse"] : "";
            $typeitem = isset($_POST["type_item"]) ? $_POST["type_item"] : "";       	

        	//BLINDAGE
        	if(empty($artiste) || empty($album) || empty($quantite)) {
				header("Location: info_musique.php?signup=empty&nom=$artiste&prenom=$album&adresse=$quantite");    
			}else{
                
        
                $id_value = $_SESSION['var'];
                                    $sql2 = "SELECT max(Code_article) FROM musique";
			
									$results = mysqli_query($db_handle, $sql2);
									$data = mysqli_fetch_assoc($results);
									$idmax=$data['max(Code_article)'];
		
                                    $idmaxi=$idmax+1;
                                    
                                    
									$addsql = "INSERT INTO `musique` (`Identifiant`,`Code_article`, `Categorie`, `Genre`, `Artiste`, `Album`, `Quantite`) VALUES ($id_value, $idmaxi, 'Musique', '$typeitem', '$artiste', '$album', $quantite)";
									//RAJOUTER LES AJOUTS DE PHOTOS
                                    $result2 = mysqli_query($db_handle, $addsql);   
                                    header("Location: info_musique.php");                            
                                   
									
									exit();
								}
							
							
		}
		else{
		echo 'BD not found';
		}
		mysqli_close($db_handle);	 
	

	  
?>

