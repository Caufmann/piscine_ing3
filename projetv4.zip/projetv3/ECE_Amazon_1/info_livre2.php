<?php  
session_start();

	//identifier votre BDD 
	
		$database = "ece_amazon";
		$db_handle = mysqli_connect('localhost', 'root', '');
		$db_found = mysqli_select_db($db_handle, $database);
		if($db_found){	        	

			$auteur = isset($_POST["Nom"]) ? $_POST["Nom"] : "";			
			$editeur = isset($_POST["Prenom"]) ? $_POST["Prenom"] : "";		
            $quantite = isset($_POST["Adresse"]) ? $_POST["Adresse"] : "";
            $typeitem = isset($_POST["type_item"]) ? $_POST["type_item"] : "";       	

        	//BLINDAGE
        	if(empty($auteur) || empty($editeur) || empty($quantite)) {
				header("Location: info_livre.php?signup=empty&nom=$auteur&prenom=$editeur&adresse=$quantite");    
			}else{
                
        
                $id_value = $_SESSION['var'];
                                    $sql2 = "SELECT max(Code_article) FROM livre";
			
									$results = mysqli_query($db_handle, $sql2);
									$data = mysqli_fetch_assoc($results);
									$idmax=$data['max(Code_article)'];
		
                                    $idmaxi=$idmax+1;
                                    
                                    
									$addsql = "INSERT INTO `livre` (`Identifiant`,`Code_article`, `Categorie`, `Genre`, `Auteur`, `Editeur`, `Quantite`) VALUES ($id_value, $idmaxi, 'Livre', '$typeitem', '$auteur', '$editeur', $quantite)";
									//RAJOUTER LES AJOUTS DE PHOTOS
                                    $result2 = mysqli_query($db_handle, $addsql);   
                                    header("Location: info_livre.php");                            
                                   
									
									exit();
								}
							
							
		}
		else{
		echo 'BD not found';
		}
		mysqli_close($db_handle);	 
	

	  
?>

