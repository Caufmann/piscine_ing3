<?php  
session_start();

	//identifier votre BDD 
	
		$database = "ece_amazon";
		$db_handle = mysqli_connect('localhost', 'root', '');
		$db_found = mysqli_select_db($db_handle, $database);
		if($db_found){	        	

			$marque = isset($_POST["Nom"]) ? $_POST["Nom"] : "";			
				
            $quantite = isset($_POST["Adresse"]) ? $_POST["Adresse"] : "";
            $typeitem = isset($_POST["type_item"]) ? $_POST["type_item"] : "";       	

        	//BLINDAGE
        	if(empty($marque) || empty($quantite)) {
				header("Location: info_sport.php?signup=empty&nom=$marque&adresse=$quantite");    
			}else{
                
        
                $id_value = $_SESSION['var'];
                                    $sql2 = "SELECT max(Code_article) FROM sport";
			
									$results = mysqli_query($db_handle, $sql2);
									$data = mysqli_fetch_assoc($results);
									$idmax=$data['max(Code_article)'];
		
                                    $idmaxi=$idmax+1;
                                    
                                    
									$addsql = "INSERT INTO `sport` (`Identifiant`,`Code_article`, `Categorie`, `Nom_activite`, `Marque`, `Quantite`) VALUES ($id_value, $idmaxi, 'Sport', '$typeitem', '$marque', $quantite)";
									//RAJOUTER LES AJOUTS DE PHOTOS
                                    $result2 = mysqli_query($db_handle, $addsql);   
                                    header("Location: info_sport.php");                            
                                   
									
									exit();
								}
							
							
		}
		else{
		echo 'BD not found';
		}
		mysqli_close($db_handle);	 
	

	  
?>

